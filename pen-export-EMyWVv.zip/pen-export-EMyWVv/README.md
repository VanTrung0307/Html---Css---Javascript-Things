# The Cube

A Pen created on CodePen.io. Original URL: [https://codepen.io/bsehovac/pen/EMyWVv](https://codepen.io/bsehovac/pen/EMyWVv).

See if you can solve this classic Rubik's puzzle game made in three.js.